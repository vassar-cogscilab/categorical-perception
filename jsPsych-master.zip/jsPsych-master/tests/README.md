# Testing jsPsych

Tests are written with [Jest](https://facebook.github.io/jest/).

To run the tests, install Node and npm. Run `npm install` in the root jsPsych directory. Then run `npm test`.

To add tests, follow examples contained in this folder. 
